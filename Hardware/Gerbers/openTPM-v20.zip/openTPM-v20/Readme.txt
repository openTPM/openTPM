
Size: 72.3mm x 76.5mm
Soldermask: Red
Silkscreen: White
Thickness 1.2mm
Copper Weight: 1oz
Finish: ENIG
Layers: 2
Material: FR4

100% E-Test

No manufacturer markings on PCB.

Manufacturing identifcation or batch code must be added on margin of the panel.